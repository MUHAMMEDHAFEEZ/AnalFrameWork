"""CLI module initialization."""

from anal.cli.main import main, app

__all__ = ["main", "app"]
