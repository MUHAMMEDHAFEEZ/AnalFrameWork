"""
Setup script for ANAL Framework.

This file exists mainly for compatibility and development purposes.
The actual package configuration is in pyproject.toml.
"""

from setuptools import setup

setup()
